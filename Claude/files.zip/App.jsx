import { BrowserRouter, Routes, Route, Link, Navigate } from 'react-router'
import Dashboard from './pages/Dashboard'
import Login from './pages/Login'
import Signup from './pages/Signup'
import './App.css'

function App() {
  return (
  

      <Routes>
        {/* Redirect root "/" to "/login" or "/dashboard" */}
        <Route path="/" element={<Navigate to="/login" replace />} />
        
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
      </Routes>
  
  )
}

export default App